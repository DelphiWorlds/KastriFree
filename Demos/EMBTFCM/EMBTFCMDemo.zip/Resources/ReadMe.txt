For Android, put:

  strings.xml

..and/or for iOS put:

  GoogleService-info.plist

Into this folder (i.e. the folder that this readme.txt is in)